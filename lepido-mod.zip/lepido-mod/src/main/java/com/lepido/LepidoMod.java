package com.lepido;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LepidoMod implements ModInitializer {
    public static final String MOD_ID = "lepido";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModBlocks.registerBlocks();
        ModBlockEntities.registerBlockEntities();
        ModEntities.registerEntities();
        ModItems.registerItems();
        ModCommands.registerCommands();
        LepidoEvents.register();
        LOGGER.info("[Lepidodendron Mod] инициализация завершена");
    }
}
