package com.lepido.client;

import com.lepido.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.renderer.entity.ZombieRenderer;

public class ModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.LEPIDO_GUARDIAN, ZombieRenderer::new);
        EntityRendererRegistry.register(ModEntities.FOG_GOLEM, ZombieRenderer::new);
        EntityRendererRegistry.register(ModEntities.LEPIDO_LORD, ZombieRenderer::new);
        EntityRendererRegistry.register(ModEntities.GALAXY_DEVOURER, ZombieRenderer::new);
    }
}
