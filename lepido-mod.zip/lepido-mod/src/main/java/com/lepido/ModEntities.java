package com.lepido;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class ModEntities {
    private ModEntities() {}

    // Мини-боссы
    public static final EntityType<LepidoGuardianEntity> LEPIDO_GUARDIAN = register("lepidodendron_guardian",
            EntityType.Builder.of(LepidoGuardianEntity::new, MobCategory.MONSTER).sized(0.9F, 2.6F));
    public static final EntityType<FogGolemEntity> FOG_GOLEM = register("fog_golem",
            EntityType.Builder.of(FogGolemEntity::new, MobCategory.MONSTER).sized(1.2F, 3.2F));
    // Боссы
    public static final EntityType<LepidoLordEntity> LEPIDO_LORD = register("lepidodendron_lord",
            EntityType.Builder.of(LepidoLordEntity::new, MobCategory.MONSTER).sized(1.5F, 4.2F));
    public static final EntityType<GalaxyDevourerEntity> GALAXY_DEVOURER = register("galaxy_devourer",
            EntityType.Builder.of(GalaxyDevourerEntity::new, MobCategory.MONSTER).sized(2.8F, 8.5F));

    private static <T extends Entity> EntityType<T> register(String name, EntityType.Builder<T> builder) {
        return Registry.register(BuiltInRegistries.ENTITY_TYPE,
                ResourceLocation.fromNamespaceAndPath(LepidoMod.MOD_ID, name), builder.build(name));
    }

    public static void registerEntities() {
        FabricDefaultAttributeRegistry.register(LEPIDO_GUARDIAN, LepidoGuardianEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(FOG_GOLEM, FogGolemEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(LEPIDO_LORD, LepidoLordEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(GALAXY_DEVOURER, GalaxyDevourerEntity.createAttributes());
    }
}
