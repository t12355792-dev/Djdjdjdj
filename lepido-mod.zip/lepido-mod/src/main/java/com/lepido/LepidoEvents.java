package com.lepido;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;

public final class LepidoEvents {
    /** Ключ измерения лепидодендрона. */
    public static final ResourceKey<Level> REALM_KEY = ResourceKey.create(Registries.DIMENSION,
            ResourceLocation.fromNamespaceAndPath(LepidoMod.MOD_ID, "lepido_realm"));

    /** Через сколько миллисекунд игрок умирает в измерении (2 минуты). */
    private static final long DEATH_DELAY_MS = 120_000L;
    /** Предупреждение за 15 секунд до гибели. */
    private static final long WARNING_BEFORE_MS = 15_000L;
    /** Шанс спавна дерева рядом с игроком за секунду: 0.01. */
    public static final float TREE_SPAWN_CHANCE_PER_SECOND = 0.01F;

    private static final Map<UUID, Long> ENTRY_TIME = new HashMap<>();
    private static final Set<UUID> WARNED = new HashSet<>();
    private static final Random RANDOM = new Random();

    private LepidoEvents() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(LepidoEvents::onServerTick);
        registerOreGeneration();
    }

    private static void registerOreGeneration() {
        addOre("ore_adamantite");
        addOre("ore_mithril");
        addOre("ore_onyx");
        addOre("ore_star_metal");
        addOre("ore_voidite");
    }

    private static void addOre(String placedFeatureName) {
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                GenerationStep.Feature.UNDERGROUND_ORES,
                ResourceKey.create(Registries.PLACED_FEATURE,
                        ResourceLocation.fromNamespaceAndPath(LepidoMod.MOD_ID, placedFeatureName)));
    }

    private static void onServerTick(MinecraftServer server) {
        if (server.getTickCount() % 20L != 0L) {
            return; // логика раз в секунду
        }
        ServerLevel realm = server.getLevel(REALM_KEY);
        if (realm != null) {
            checkRealmDeathTimer(realm);
        }
        ServerLevel overworld = server.overworld();
        if (overworld != null) {
            trySpawnTreesNearPlayers(overworld);
        }
    }

    private static void checkRealmDeathTimer(ServerLevel realm) {
        long now = System.currentTimeMillis();
        for (Player player : realm.players()) {
            if (!(player instanceof ServerPlayer sp)) {
                continue;
            }
            if (sp.isCreative() || sp.isSpectator()) {
                continue;
            }
            Long entry = ENTRY_TIME.get(sp.getUUID());
            if (entry == null) {
                ENTRY_TIME.put(sp.getUUID(), now);
                continue;
            }
            long elapsed = now - entry;
            if (elapsed >= DEATH_DELAY_MS - WARNING_BEFORE_MS && elapsed < DEATH_DELAY_MS
                    && WARNED.add(sp.getUUID())) {
                sp.sendSystemMessage(Component.literal(
                        "§c§lВаша жизнь в этом измерении почти истекла..."));
            }
            if (elapsed >= DEATH_DELAY_MS) {
                ENTRY_TIME.remove(sp.getUUID());
                WARNED.remove(sp.getUUID());
                sp.kill();
            }
        }
    }

    private static void trySpawnTreesNearPlayers(ServerLevel level) {
        for (Player player : level.players()) {
            if (player.isCreative() || player.isSpectator()) {
                continue;
            }
            if (RANDOM.nextFloat() < TREE_SPAWN_CHANCE_PER_SECOND) {
                double angle = RANDOM.nextDouble() * Math.PI * 2.0D;
                int dist = 24 + RANDOM.nextInt(41);
                int x = player.getBlockX() + (int) Math.round(Math.cos(angle) * dist);
                int z = player.getBlockZ() + (int) Math.round(Math.sin(angle) * dist);
                try {
                    level.getChunk(x >> 4, z >> 4);
                    int y = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
                    BlockPos base = new BlockPos(x, y, z);
                    if (!level.getBlockState(base).isAir()) {
                        continue;
                    }
                    if (!level.getBlockState(base.below()).blocksMotion()) {
                        continue;
                    }
                    if (y > level.getMinBuildHeight() + 5) {
                        placeTree(level, base);
                    }
                } catch (Exception ignored) {
                    // неудачная попытка спавна не должна ломать игру
                }
            }
        }
    }

    public static void enterRealm(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        ServerLevel realm = server.getLevel(REALM_KEY);
        if (realm == null) {
            LepidoMod.LOGGER.warn("Измерение {} не найдено", REALM_KEY.location());
            return;
        }
        try {
            int x = player.getBlockX();
            int z = player.getBlockZ();
            int y = realm.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
            BlockPos landing = new BlockPos(x, Math.max(y, realm.getMinBuildHeight() + 2), z);
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = 0; dy <= 3; dy++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        realm.setBlock(landing.offset(dx, dy, dz), Blocks.AIR.defaultBlockState(), 3);
                    }
                }
            }
            realm.setBlock(landing.below(), Blocks.OBSIDIAN.defaultBlockState(), 3);
            ENTRY_TIME.put(player.getUUID(), System.currentTimeMillis());
            WARNED.remove(player.getUUID());
            player.teleportTo(realm, landing.getX() + 0.5D, landing.getY(), landing.getZ() + 0.5D,
                    player.getYRot(), player.getXRot());
            player.sendSystemMessage(Component.literal(
                    "§8Туман поглощает вас... §7Вы в измерении Лепидодендрона. У вас §c2 минуты§7."));
        } catch (Exception e) {
            LepidoMod.LOGGER.error("Не удалось телепортировать игрока в измерение лепидодендрона", e);
        }
    }

    public static void placeLepidodendron(ServerLevel level, BlockPos ground) {
        placeTree(level, ground.above());
    }

    public static void placeTree(ServerLevel level, BlockPos base) {
        int height = 7 + RANDOM.nextInt(3);
        for (int i = 0; i < height; i++) {
            level.setBlock(base.above(i), ModBlocks.LEPIDODENDRON_LOG.defaultBlockState(), 3);
        }
        placeLeaves(level, base.above(height - 1));
    }

    public static void placeLeaves(Level level, BlockPos top) {
        for (int dy = -1; dy <= 2; dy++) {
            int radius = dy <= 0 ? 2 : (dy == 1 ? 2 : 1);
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (Math.abs(dx) == radius && Math.abs(dz) == radius && RANDOM.nextBoolean()) {
                        continue;
                    }
                    BlockPos leafPos = top.offset(dx, dy, dz);
                    if (level.getBlockState(leafPos).isAir()) {
                        level.setBlock(leafPos, ModBlocks.LEPIDODENDRON_LEAVES.defaultBlockState(), 3);
                    }
                }
            }
        }
    }
}
