package com.lepido;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.entity.BlockEntityType;

public final class ModBlockEntities {
    private ModBlockEntities() {}

    public static final BlockEntityType<LepidodendronLogBlockEntity> LEPIDODENDRON_LOG = Registry.register(
            BuiltInRegistries.BLOCK_ENTITY_TYPE,
            ResourceLocation.fromNamespaceAndPath(LepidoMod.MOD_ID, "lepidodendron_log"),
            BlockEntityType.Builder.of(LepidodendronLogBlockEntity::new, ModBlocks.LEPIDODENDRON_LOG).build());

    public static void registerBlockEntities() {
        // статическая инициализация поля выше
    }
}
