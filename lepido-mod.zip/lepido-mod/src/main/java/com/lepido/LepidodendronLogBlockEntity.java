package com.lepido;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

public class LepidodendronLogBlockEntity extends BlockEntity {
    /** Радиус срабатывания телепорта: 7 блоков и меньше. */
    public static final double TRIGGER_RADIUS = 7.0D;
    /** Проверка каждые 5 тиков — без лагов и пропусков срабатывания. */
    private static final long CHECK_INTERVAL_TICKS = 5L;

    public LepidodendronLogBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.LEPIDODENDRON_LOG, pos, state);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, LepidodendronLogBlockEntity be) {
        if (level.isClientSide()) {
            return;
        }
        if (level.getGameTime() % CHECK_INTERVAL_TICKS != 0L) {
            return;
        }
        try {
            AABB triggerBox = new AABB(pos).inflate(TRIGGER_RADIUS);
            List<Player> players = level.getEntitiesOfClass(Player.class, triggerBox);
            for (Player player : players) {
                if (player.isCreative() || player.isSpectator()) {
                    continue;
                }
                if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
                    LepidoEvents.enterRealm(serverPlayer);
                }
            }
        } catch (Exception e) {
            LepidoMod.LOGGER.error("Ошибка при проверке игроков у лепидодендрона", e);
        }
    }
}
