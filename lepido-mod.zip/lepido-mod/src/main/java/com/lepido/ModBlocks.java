package com.lepido;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

public final class ModBlocks {
    private ModBlocks() {}

    public static final Block ADAMANTITE_ORE = register("adamantite_ore", new DropExperienceBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).requiresCorrectToolForDrops()
                    .strength(4.0F, 3.0F).sound(SoundType.STONE),
            UniformInt.of(3, 7)));
    public static final Block MITHRIL_ORE = register("mithril_ore", new DropExperienceBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_BLUE).requiresCorrectToolForDrops()
                    .strength(4.5F, 3.5F).sound(SoundType.STONE),
            UniformInt.of(3, 7)));
    public static final Block ONYX_ORE = register("onyx_ore", new DropExperienceBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).requiresCorrectToolForDrops()
                    .strength(5.0F, 4.0F).sound(SoundType.DEEPSLATE),
            UniformInt.of(4, 8)));
    public static final Block STAR_METAL_ORE = register("star_metal_ore", new DropExperienceBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_YELLOW).requiresCorrectToolForDrops()
                    .strength(5.0F, 4.0F).sound(SoundType.STONE),
            UniformInt.of(4, 8)));
    public static final Block VOIDITE_ORE = register("voidite_ore", new DropExperienceBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_CYAN).requiresCorrectToolForDrops()
                    .strength(6.0F, 5.0F).sound(SoundType.DEEPSLATE),
            UniformInt.of(5, 9)));
    public static final Block LEPIDODENDRON_LOG = register("lepidodendron_log",
            new LepidodendronLogBlock(BlockBehaviour.Properties.of().mapColor(MapColor.TERRACOTTA_BROWN)
                    .strength(2.5F).sound(SoundType.WOOD)));
    public static final Block LEPIDODENDRON_LEAVES = register("lepidodendron_leaves",
            new Block(BlockBehaviour.Properties.of().mapColor(MapColor.PLANT)
                    .strength(0.3F).sound(SoundType.GRASS).noOcclusion()));

    private static Block register(String name, Block block) {
        return Registry.register(BuiltInRegistries.BLOCK,
                ResourceLocation.fromNamespaceAndPath(LepidoMod.MOD_ID, name), block);
    }

    public static void registerBlocks() {
        // статическая инициализация полей выше
    }
}
