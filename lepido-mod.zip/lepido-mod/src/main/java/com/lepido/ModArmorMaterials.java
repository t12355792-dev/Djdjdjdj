package com.lepido;

import java.util.EnumMap;
import java.util.Map;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Util;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;

public enum ModArmorMaterials implements ArmorMaterial {
    ADAMANTITE("adamantite", 33, 18, 2.0F, 0.0F, SoundEvents.ARMOR_EQUIP_NETHERITE,
            defense(3, 8, 6, 3)),
    MITHRIL("mithril", 30, 22, 2.0F, 0.05F, SoundEvents.ARMOR_EQUIP_DIAMOND,
            defense(3, 8, 6, 3)),
    ONYX("onyx", 37, 20, 2.5F, 0.05F, SoundEvents.ARMOR_EQUIP_NETHERITE,
            defense(4, 9, 7, 4)),
    STAR_METAL("star_metal", 40, 26, 3.0F, 0.10F, SoundEvents.ARMOR_EQUIP_DIAMOND,
            defense(4, 9, 7, 4)),
    VOIDITE("voidite", 45, 30, 4.0F, 0.15F, SoundEvents.ARMOR_EQUIP_NETHERITE,
            defense(5, 10, 8, 5));

    private final String assetName;
    private final int durabilityMultiplier;
    private final int enchantmentValue;
    private final float toughness;
    private final float knockbackResistance;
    private final Holder<SoundEvent> equipSound;
    private final Map<ArmorType, Integer> defense;

    ModArmorMaterials(String assetName, int durabilityMultiplier, int enchantmentValue,
                      float toughness, float knockbackResistance, Holder<SoundEvent> equipSound,
                      Map<ArmorType, Integer> defense) {
        this.assetName = assetName;
        this.durabilityMultiplier = durabilityMultiplier;
        this.enchantmentValue = enchantmentValue;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
        this.equipSound = equipSound;
        this.defense = defense;
    }

    private static Map<ArmorType, Integer> defense(int boots, int leggings, int chestplate, int helmet) {
        return Util.make(new EnumMap<>(ArmorType.class), map -> {
            map.put(ArmorType.BOOTS, boots);
            map.put(ArmorType.LEGGINGS, leggings);
            map.put(ArmorType.CHESTPLATE, chestplate);
            map.put(ArmorType.HELMET, helmet);
        });
    }

    private static TagKey<Item> repairTag(String assetName) {
        return TagKey.create(Registries.ITEM,
                ResourceLocation.fromNamespaceAndPath(LepidoMod.MOD_ID, "repair_" + assetName));
    }

    @Override
    public int getDurability(ArmorType type) {
        return type.getDurability(this.durabilityMultiplier);
    }

    @Override
    public int getDefense(ArmorType type) {
        return this.defense.getOrDefault(type, 0);
    }

    @Override
    public int getEnchantmentValue() {
        return this.enchantmentValue;
    }

    @Override
    public Holder<SoundEvent> getEquipSound() {
        return this.equipSound;
    }

    @Override
    public TagKey<Item> getRepairItem() {
        return repairTag(this.assetName);
    }

    @Override
    public ResourceLocation getName() {
        return ResourceLocation.fromNamespaceAndPath(LepidoMod.MOD_ID, this.assetName);
    }

    @Override
    public float getToughness() {
        return this.toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return this.knockbackResistance;
    }
}
