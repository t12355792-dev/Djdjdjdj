package com.lepido;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.level.block.Block;

public final class ModToolMaterials {
    private ModToolMaterials() {}

    private static TagKey<Item> repair(String name) {
        return TagKey.create(Registries.ITEM,
                ResourceLocation.fromNamespaceAndPath(LepidoMod.MOD_ID, "repair_" + name));
    }

    public static final ToolMaterial ADAMANTITE = new ToolMaterial(
            BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 2600, 8.5F, 4.0F, 18, repair("adamantite"));
    public static final ToolMaterial MITHRIL = new ToolMaterial(
            BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 2300, 9.5F, 4.0F, 22, repair("mithril"));
    public static final ToolMaterial ONYX = new ToolMaterial(
            BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 2000, 8.0F, 4.0F, 20, repair("onyx"));
    public static final ToolMaterial STAR_METAL = new ToolMaterial(
            BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 3200, 10.0F, 4.0F, 26, repair("star_metal"));
    public static final ToolMaterial VOIDITE = new ToolMaterial(
            BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 4200, 11.0F, 8.0F, 30, repair("voidite"));
}
