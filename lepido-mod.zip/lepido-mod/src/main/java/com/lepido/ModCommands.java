package com.lepido;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public final class ModCommands {
    private ModCommands() {}

    public static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(Commands.literal("galaktika")
                    .requires(source -> source.hasPermission(2))
                    .executes(context -> {
                        ServerPlayer player = context.getSource().getPlayerOrException();
                        ItemStack axe = new ItemStack(ModItems.GALAXY_AXE);
                        if (!player.getInventory().add(axe)) {
                            player.drop(axe, false);
                        }
                        player.sendSystemMessage(Component.literal(
                                "§6§l\u26A1 ТОПОР ГАЛАКТИКИ \u26A1§r §eВыдан! Урон: 7777."));
                        return 1;
                    }));

            dispatcher.register(Commands.literal("lepidodendron")
                    .requires(source -> source.hasPermission(2))
                    .executes(context -> {
                        ServerPlayer player = context.getSource().getPlayerOrException();
                        Level level = player.level();
                        Vec3 point = player.getEyePosition().add(player.getLookAngle().scale(20.0D));
                        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos(
                                Mth.floor(point.x),
                                Mth.clamp(Mth.floor(point.y), level.getMinBuildHeight(), level.getMaxBuildHeight()),
                                Mth.floor(point.z));
                        boolean found = false;
                        while (cursor.getY() > level.getMinBuildHeight()) {
                            if (level.getBlockState(cursor.below()).blocksMotion()
                                    && level.getBlockState(cursor).isAir()) {
                                found = true;
                                break;
                            }
                            cursor.move(Direction.DOWN);
                        }
                        if (!found) {
                            cursor.set(cursor.getX(), level.getSeaLevel(), cursor.getZ());
                        }
                        if (level instanceof ServerLevel serverLevel) {
                            LepidoEvents.placeLepidodendron(serverLevel, cursor.immutable());
                        }
                        player.sendSystemMessage(Component.literal(
                                "§2Лепидодендрон вырос примерно в 20 блоках от вас. Подходите — если осмелитесь."));
                        return 1;
                    }));
        });
    }
}
