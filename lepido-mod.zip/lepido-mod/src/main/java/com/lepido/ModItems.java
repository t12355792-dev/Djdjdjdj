package com.lepido;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ArmorType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;

public final class ModItems {
    private ModItems() {}

    // --- Блоки как предметы ---
    public static final Item ADAMANTITE_ORE = blockItem("adamantite_ore", ModBlocks.ADAMANTITE_ORE);
    public static final Item MITHRIL_ORE = blockItem("mithril_ore", ModBlocks.MITHRIL_ORE);
    public static final Item ONYX_ORE = blockItem("onyx_ore", ModBlocks.ONYX_ORE);
    public static final Item STAR_METAL_ORE = blockItem("star_metal_ore", ModBlocks.STAR_METAL_ORE);
    public static final Item VOIDITE_ORE = blockItem("voidite_ore", ModBlocks.VOIDITE_ORE);
    public static final Item LEPIDODENDRON_LOG = blockItem("lepidodendron_log", ModBlocks.LEPIDODENDRON_LOG);
    public static final Item LEPIDODENDRON_LEAVES = blockItem("lepidodendron_leaves", ModBlocks.LEPIDODENDRON_LEAVES);

    // --- Сырье ---
    public static final Item RAW_ADAMANTITE = simple("raw_adamantite");
    public static final Item RAW_MITHRIL = simple("raw_mithril");
    public static final Item RAW_STAR_METAL = simple("raw_star_metal");
    public static final Item RAW_VOIDITE = simple("raw_voidite");

    // --- Обработанные материалы ---
    public static final Item ADAMANTITE_INGOT = simple("adamantite_ingot");
    public static final Item MITHRIL_INGOT = simple("mithril_ingot");
    public static final Item ONYX = simple("onyx");
    public static final Item STAR_METAL_INGOT = simple("star_metal_ingot");
    public static final Item VOIDITE_INGOT = simple("voidite_ingot");

    // --- Топоры: итоговый урон = бонус материала + параметр ---
    public static final Item KRATOS_AXE = register("kratos_axe",
            new Item(new Item.Properties().axe(ModToolMaterials.ADAMANTITE, 2.0F, -3.0F)));      // урон 7
    public static final Item ZEUS_AXE = register("zeus_axe",
            new Item(new Item.Properties().axe(ModToolMaterials.MITHRIL, 6.0F, -3.0F)));          // урон 11
    public static final Item HADES_AXE = register("hades_axe",
            new Item(new Item.Properties().axe(ModToolMaterials.ONYX, 10.0F, -3.0F)));            // урон 15
    public static final Item CELESTIAL_AXE = register("celestial_axe",
            new Item(new Item.Properties().axe(ModToolMaterials.STAR_METAL, 20.0F, -3.0F)));      // урон 25
    public static final Item GALAXY_AXE = register("galaxy_axe",
            new Item(new Item.Properties().axe(ModToolMaterials.VOIDITE, 7768.0F, -3.0F)
                    .rarity(Rarity.EPIC).fireResistant()));                                       // урон 7777

    // --- Броня: 5 материалов x 4 части ---
    public static final Item ADAMANTITE_HELMET = armor("adamantite", ModArmorMaterials.ADAMANTITE, ArmorType.HELMET, 33);
    public static final Item ADAMANTITE_CHESTPLATE = armor("adamantite", ModArmorMaterials.ADAMANTITE, ArmorType.CHESTPLATE, 33);
    public static final Item ADAMANTITE_LEGGINGS = armor("adamantite", ModArmorMaterials.ADAMANTITE, ArmorType.LEGGINGS, 33);
    public static final Item ADAMANTITE_BOOTS = armor("adamantite", ModArmorMaterials.ADAMANTITE, ArmorType.BOOTS, 33);
    public static final Item MITHRIL_HELMET = armor("mithril", ModArmorMaterials.MITHRIL, ArmorType.HELMET, 30);
    public static final Item MITHRIL_CHESTPLATE = armor("mithril", ModArmorMaterials.MITHRIL, ArmorType.CHESTPLATE, 30);
    public static final Item MITHRIL_LEGGINGS = armor("mithril", ModArmorMaterials.MITHRIL, ArmorType.LEGGINGS, 30);
    public static final Item MITHRIL_BOOTS = armor("mithril", ModArmorMaterials.MITHRIL, ArmorType.BOOTS, 30);
    public static final Item ONYX_HELMET = armor("onyx", ModArmorMaterials.ONYX, ArmorType.HELMET, 37);
    public static final Item ONYX_CHESTPLATE = armor("onyx", ModArmorMaterials.ONYX, ArmorType.CHESTPLATE, 37);
    public static final Item ONYX_LEGGINGS = armor("onyx", ModArmorMaterials.ONYX, ArmorType.LEGGINGS, 37);
    public static final Item ONYX_BOOTS = armor("onyx", ModArmorMaterials.ONYX, ArmorType.BOOTS, 37);
    public static final Item STAR_METAL_HELMET = armor("star_metal", ModArmorMaterials.STAR_METAL, ArmorType.HELMET, 40);
    public static final Item STAR_METAL_CHESTPLATE = armor("star_metal", ModArmorMaterials.STAR_METAL, ArmorType.CHESTPLATE, 40);
    public static final Item STAR_METAL_LEGGINGS = armor("star_metal", ModArmorMaterials.STAR_METAL, ArmorType.LEGGINGS, 40);
    public static final Item STAR_METAL_BOOTS = armor("star_metal", ModArmorMaterials.STAR_METAL, ArmorType.BOOTS, 40);
    public static final Item VOIDITE_HELMET = armor("voidite", ModArmorMaterials.VOIDITE, ArmorType.HELMET, 45);
    public static final Item VOIDITE_CHESTPLATE = armor("voidite", ModArmorMaterials.VOIDITE, ArmorType.CHESTPLATE, 45);
    public static final Item VOIDITE_LEGGINGS = armor("voidite", ModArmorMaterials.VOIDITE, ArmorType.LEGGINGS, 45);
    public static final Item VOIDITE_BOOTS = armor("voidite", ModArmorMaterials.VOIDITE, ArmorType.BOOTS, 45);

    // --- Яйца призыва боссов ---
    public static final Item LEPIDO_GUARDIAN_SPAWN_EGG = register("lepidodendron_guardian_spawn_egg",
            new net.fabricmc.fabric.api.object.builder.v1.entity.DeferredSpawnEggItem(
                    () -> ModEntities.LEPIDO_GUARDIAN, 0x2F4A2F, 0x8FBF8F, new Item.Properties()));
    public static final Item FOG_GOLEM_SPAWN_EGG = register("fog_golem_spawn_egg",
            new net.fabricmc.fabric.api.object.builder.v1.entity.DeferredSpawnEggItem(
                    () -> ModEntities.FOG_GOLEM, 0x9AA5B0, 0x5A6570, new Item.Properties()));
    public static final Item LEPIDO_LORD_SPAWN_EGG = register("lepidodendron_lord_spawn_egg",
            new net.fabricmc.fabric.api.object.builder.v1.entity.DeferredSpawnEggItem(
                    () -> ModEntities.LEPIDO_LORD, 0x1E3A1E, 0xBFDFFF, new Item.Properties()));
    public static final Item GALAXY_DEVOURER_SPAWN_EGG = register("galaxy_devourer_spawn_egg",
            new net.fabricmc.fabric.api.object.builder.v1.entity.DeferredSpawnEggItem(
                    () -> ModEntities.GALAXY_DEVOURER, 0x1A1030, 0xFFB0FF, new Item.Properties()));

    private static Item register(String name, Item item) {
        return Registry.register(BuiltInRegistries.ITEM,
                ResourceLocation.fromNamespaceAndPath(LepidoMod.MOD_ID, name), item);
    }

    private static Item simple(String name) {
        return register(name, new Item(new Item.Properties()));
    }

    private static Item blockItem(String name, Block block) {
        return register(name, new BlockItem(block, new Item.Properties()));
    }

    private static Item armor(String name, Object material, ArmorType type, int durability) {
        @SuppressWarnings("unchecked")
        net.minecraft.world.item.equipment.ArmorMaterial mat =
                (net.minecraft.world.item.equipment.ArmorMaterial) material;
        String suffix = switch (type) {
            case HELMET -> "helmet";
            case CHESTPLATE -> "chestplate";
            case LEGGINGS -> "leggings";
            case BOOTS -> "boots";
            default -> "body";
        };
        return register(name + "_" + suffix,
                new Item(new Item.Properties().armor(mat, type).durability(type.getDurability(durability))));
    }

    public static void registerItems() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.NATURAL_BLOCKS).register(entries -> {
            entries.accept(ADAMANTITE_ORE);
            entries.accept(MITHRIL_ORE);
            entries.accept(ONYX_ORE);
            entries.accept(STAR_METAL_ORE);
            entries.accept(VOIDITE_ORE);
            entries.accept(LEPIDODENDRON_LOG);
            entries.accept(LEPIDODENDRON_LEAVES);
        });
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(entries -> {
            entries.accept(RAW_ADAMANTITE);
            entries.accept(RAW_MITHRIL);
            entries.accept(RAW_STAR_METAL);
            entries.accept(RAW_VOIDITE);
            entries.accept(ADAMANTITE_INGOT);
            entries.accept(MITHRIL_INGOT);
            entries.accept(ONYX);
            entries.accept(STAR_METAL_INGOT);
            entries.accept(VOIDITE_INGOT);
        });
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> {
            entries.accept(KRATOS_AXE);
            entries.accept(ZEUS_AXE);
            entries.accept(HADES_AXE);
            entries.accept(CELESTIAL_AXE);
            entries.accept(GALAXY_AXE);
        });
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(entries -> {
            entries.accept(ADAMANTITE_HELMET);
            entries.accept(ADAMANTITE_CHESTPLATE);
            entries.accept(ADAMANTITE_LEGGINGS);
            entries.accept(ADAMANTITE_BOOTS);
            entries.accept(MITHRIL_HELMET);
            entries.accept(MITHRIL_CHESTPLATE);
            entries.accept(MITHRIL_LEGGINGS);
            entries.accept(MITHRIL_BOOTS);
            entries.accept(ONYX_HELMET);
            entries.accept(ONYX_CHESTPLATE);
            entries.accept(ONYX_LEGGINGS);
            entries.accept(ONYX_BOOTS);
            entries.accept(STAR_METAL_HELMET);
            entries.accept(STAR_METAL_CHESTPLATE);
            entries.accept(STAR_METAL_LEGGINGS);
            entries.accept(STAR_METAL_BOOTS);
            entries.accept(VOIDITE_HELMET);
            entries.accept(VOIDITE_CHESTPLATE);
            entries.accept(VOIDITE_LEGGINGS);
            entries.accept(VOIDITE_BOOTS);
        });
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.SPAWN_EGGS).register(entries -> {
            entries.accept(LEPIDO_GUARDIAN_SPAWN_EGG);
            entries.accept(FOG_GOLEM_SPAWN_EGG);
            entries.accept(LEPIDO_LORD_SPAWN_EGG);
            entries.accept(GALAXY_DEVOURER_SPAWN_EGG);
        });
    }
}
